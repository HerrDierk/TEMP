sleep 30s
killall conky
cd "/home/lunix/.conky"
conky -c "/home/lunix/.conky/Connection" &
cd "/home/lunix/.conky"
conky -c "/home/lunix/.conky/System" &
